#!/bin/bash

tar -cvzf bacup.tar.gz /workspaces/GitTreino/Terminal/{backup,bash_scripts,cat,sort,super_secret_stuff,tarball} 2>/dev/null
