#!/bin/bash

mkdir /workspaces/GitTreino/Terminal/bash_scripts/magic
cd /workspaces/GitTreino/Terminal/bash_scripts/magic
touch file{1..100}
ls -lh /workspaces/GitTreino/Terminal/bash_scripts/magic > /workspaces/GitTreino/Terminal/bash_scripts/magic.log